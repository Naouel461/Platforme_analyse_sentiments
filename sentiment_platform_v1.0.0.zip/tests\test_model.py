import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))

import pytest
from main import analyser_sentiment

def test_model_multilingual_fr():
    """Test du modèle en français"""
    score, sentiment = analyser_sentiment("Ce produit est excellent")
    assert sentiment == "POSITIVE"

def test_model_multilingual_ar():
    """Test du modèle en arabe"""
    score, sentiment = analyser_sentiment("منتج رائع")
    assert sentiment == "POSITIVE"

def test_model_neutral():
    """Test du modèle sur texte neutre"""
    score, sentiment = analyser_sentiment("Le produit est arrivé")
    assert sentiment in ["NEUTRAL", "POSITIVE"]