﻿import json
import os
from datetime import datetime

def validate_data():
    """Valide l'intégrité des données"""
    
    print("=== VALIDATION PHASE 1 ===\n")
    
    errors = []
    warnings = []
    
    # 1. Vérifier l'existence des fichiers
    required_files = [
        'data/raw/twitter_data.json',
        'data/processed/train_data.json',
        'data/processed/val_data.json',
        'data/processed/test_data.json',
        'data/processed/metadata.json'
    ]
    
    for file in required_files:
        if not os.path.exists(file):
            errors.append(f"Fichier manquant: {file}")
        else:
            size = os.path.getsize(file)
            if size == 0:
                errors.append(f"Fichier vide: {file}")
            else:
                print(f"✅ {file}: {size} bytes")
    
    # 2. Vérifier le contenu des données
    with open('data/processed/metadata.json', 'r') as f:
        meta = json.load(f)
    
    total = meta['total_samples']
    train = meta['train_samples']
    val = meta['val_samples']
    test = meta['test_samples']
    
    # Vérifier le ratio
    if train != int(total * 0.8):
        warnings.append(f"Ratio train incorrect: attendu 80%, obtenu {train/total*100:.1f}%")
    
    # 3. Vérifier les doublons
    for split in ['train', 'val', 'test']:
        with open(f'data/processed/{split}_data.json', 'r') as f:
            data = json.load(f)
            texts = [item['text'] for item in data]
            duplicates = len(texts) - len(set(texts))
            if duplicates > 0:
                warnings.append(f"{split}: {duplicates} doublons trouvés")
    
    # 4. Vérifier la qualité du texte
    with open('data/processed/train_data.json', 'r') as f:
        train_data = json.load(f)
    
    empty_texts = sum(1 for item in train_data if not item['text'].strip())
    if empty_texts > 0:
        errors.append(f"{empty_texts} textes vides dans train")
    
    # 5. Résumé
    print(f"\n📊 RÉSUMÉ VALIDATION:")
    print(f"   Total échantillons: {total}")
    print(f"   Train/Val/Test: {train}/{val}/{test}")
    print(f"   Ratio: {train/total*100:.1f}/{val/total*100:.1f}/{test/total*100:.1f}")
    
    if errors:
        print(f"\n❌ ERREURS: {len(errors)}")
        for e in errors:
            print(f"   - {e}")
    
    if warnings:
        print(f"\n⚠️ WARNINGS: {len(warnings)}")
        for w in warnings:
            print(f"   - {w}")
    
    if not errors and not warnings:
        print("\n✅ VALIDATION PASSÉE AVEC SUCCÈS!")
    
    return len(errors) == 0

if __name__ == "__main__":
    validate_data()
