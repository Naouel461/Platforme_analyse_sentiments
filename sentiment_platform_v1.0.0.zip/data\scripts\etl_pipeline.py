﻿import json
import re
import random
import hashlib
from pathlib import Path
from typing import List, Dict, Tuple


class SentimentETL:

    def __init__(self, input_file: str, output_dir: str):
        self.input_file = Path(input_file)
        self.output_dir = Path(output_dir)

        # Création du dossier de sortie si nécessaire
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def clean_text(self, text: str) -> str:
        """Nettoie le texte avant traitement"""
        text = text.lower()

        # Suppression des urls
        text = re.sub(r"http\S+|www\S+|https\S+", "", text, flags=re.MULTILINE)

        # Suppression des hashtags et mentions
        text = re.sub(r"@\w+|#\w+", "", text)

        # Garder uniquement les lettres
        text = re.sub(r"[^a-zàâçéèêëîïôûùüÿñæœ\s]", "", text)

        # Nettoyage des espaces multiples
        text = re.sub(r"\s+", " ", text).strip()

        return text

    def anonymize(self, text: str) -> str:
        """Masque certaines informations sensibles"""
        # Remplacement des emails
        text = re.sub(r"\b[\w\.-]+@[\w\.-]+\.\w{2,}\b", "[EMAIL]", text)

        # Remplacement simple des noms propres
        text = re.sub(r"\b[A-Z][a-z]+\b", "[NOM]", text)

        return text

    def process_data(self) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Lecture et préparation des données"""
        with open(self.input_file, "r", encoding="utf-8") as fichier:
            data = json.load(fichier)

        processed_data = []

        for item in data:
            cleaned_text = self.clean_text(item.get("text", ""))
            anonymized_text = self.anonymize(cleaned_text)

            # Création d'un identifiant hash
            unique_hash = hashlib.md5(anonymized_text.encode()).hexdigest()

            processed_data.append({
                "original_id": item.get("id", len(processed_data)),
                "text": anonymized_text,
                "original_sentiment": item.get("sentiment", "neutre"),
                "hash": unique_hash,
                "source": item.get("source", "google")  
            })

        # Mélange des données
        random.shuffle(processed_data)

        total = len(processed_data)
        train_limit = int(total * 0.8)
        val_limit = int(total * 0.9)

        train_data = processed_data[:train_limit]
        val_data = processed_data[train_limit:val_limit]
        test_data = processed_data[val_limit:]

        return train_data, val_data, test_data

    def save_splits(self, train_data, val_data, test_data):
        """Sauvegarde des datasets"""
        datasets = {"train": train_data, "val": val_data, "test": test_data}

        for name, data in datasets.items():
            output_file = self.output_dir / f"{name}_data.json"
            with open(output_file, "w", encoding="utf-8") as fichier:
                json.dump(data, fichier, indent=2, ensure_ascii=False)
            print(f"{len(data)} éléments sauvegardés dans {output_file}")

        # Sauvegarde des informations générales
        metadata = {
            "total_samples": len(train_data) + len(val_data) + len(test_data),
            "train_samples": len(train_data),
            "val_samples": len(val_data),
            "test_samples": len(test_data),
            "split_ratio": "80/10/10"
        }

        metadata_file = self.output_dir / "metadata.json"
        with open(metadata_file, "w", encoding="utf-8") as fichier:
            json.dump(metadata, fichier, indent=2)

    def run(self):
        print(f"Traitement du fichier : {self.input_file}")
        train_data, val_data, test_data = self.process_data()
        self.save_splits(train_data, val_data, test_data)
        print("Traitement terminé avec succès.")


if __name__ == "__main__":
    import sys

    # MODIFIÉ : google_reviews_sample.json par défaut
    input_file = (
        sys.argv[1]
        if len(sys.argv) > 1
        else "data/raw/google_reviews_sample.json"  # ← MODIFIÉ
    )

    output_dir = (
        sys.argv[2]
        if len(sys.argv) > 2
        else "data/processed"
    )

    etl = SentimentETL(input_file, output_dir)
    etl.run()