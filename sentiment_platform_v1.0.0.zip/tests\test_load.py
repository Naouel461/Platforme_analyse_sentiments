import requests
import time
import threading
from datetime import datetime

BASE_URL = "http://localhost:8002"

def test_api():
    """Test une requête sur /test-sentiment"""
    data = {"text": "Test de charge"}
    try:
        start = time.time()
        response = requests.post(f"{BASE_URL}/test-sentiment", json=data, timeout=30)
        elapsed = time.time() - start
        return {
            "status": response.status_code,
            "time": elapsed,
            "success": response.status_code == 200
        }
    except Exception as e:
        return {"status": 500, "time": 0, "success": False, "error": str(e)}

def test_load(nb_requests=100, concurrent=10):
    """Test de charge"""
    print(f"\n🚀 Test de charge: {nb_requests} requêtes, {concurrent} concurrentes")
    print("=" * 50)

    results = []
    start_time = time.time()

    def worker():
        for _ in range(nb_requests // concurrent):
            results.append(test_api())

    # Lancer les threads
    threads = []
    for _ in range(concurrent):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)

    # Attendre la fin
    for t in threads:
        t.join()

    total_time = time.time() - start_time

    # Statistiques
    success = sum(1 for r in results if r.get("success", False))
    avg_time = sum(r.get("time", 0) for r in results) / len(results) if results else 0

    print(f"\n📊 Résultats:")
    print(f"   ✅ Succès: {success}/{len(results)} ({success/len(results)*100:.1f}%)")
    print(f"   ⏱️  Temps total: {total_time:.2f}s")
    print(f"   ⏱️  Temps moyen: {avg_time:.4f}s")
    print(f"   📈 Requêtes/sec: {len(results)/total_time:.1f}")

if __name__ == "__main__":
    test_load(nb_requests=50, concurrent=5)