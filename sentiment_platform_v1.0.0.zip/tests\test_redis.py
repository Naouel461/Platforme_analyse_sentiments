import pytest
import redis
import os
from dotenv import load_dotenv

load_dotenv()

# IMPORTANT: Utiliser "localhost" pour les tests car Redis est exposé sur localhost
REDIS_HOST = "localhost"  # ← Changé de "redis" à "localhost"
REDIS_PORT = 6379

def test_redis_connection():
    """Teste la connexion à Redis"""
    try:
        r = redis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            decode_responses=True,
            socket_connect_timeout=5
        )
        assert r.ping() == True
        print("✅ Redis OK")
    except Exception as e:
        pytest.fail(f"❌ Erreur Redis: {e}")

def test_redis_push_pop():
    """Teste l'opération push/pop sur Redis"""
    r = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        decode_responses=True,
        socket_connect_timeout=5
    )
    # Nettoyer avant test
    r.delete("test_queue")
    
    # Push
    r.lpush("test_queue", "test_message")
    
    # Pop
    message = r.rpop("test_queue")
    assert message == "test_message"
    print("✅ Redis push/pop OK")

def test_redis_cache():
    """Teste le cache Redis"""
    r = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        decode_responses=True,
        socket_connect_timeout=5
    )
    
    # Mettre en cache
    r.set("test_key", "test_value", ex=10)
    
    # Récupérer
    value = r.get("test_key")
    assert value == "test_value"
    
    # Vérifier TTL
    ttl = r.ttl("test_key")
    assert ttl > 0
    
    # Nettoyer
    r.delete("test_key")
    print("✅ Cache Redis OK")