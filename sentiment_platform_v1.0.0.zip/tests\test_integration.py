import pytest
import requests
import time
import json

BASE_URL = "http://localhost:8002"

def test_workflow_complet():
    """Test complet du workflow"""
    
    print("\n" + "="*60)
    print("🧪 TEST D'INTÉGRATION COMPLET")
    print("="*60)
    
    # 1. Health check
    print("\n1️⃣ Health check...")
    response = requests.get(f"{BASE_URL}/")
    assert response.status_code == 200
    assert response.json()["status"] == "online"
    print("   ✅ Health check OK")
    
    # 2. Analyser un texte
    print("\n2️⃣ Analyse de sentiment...")
    text = "Ce produit est incroyable !"
    response = requests.post(
        f"{BASE_URL}/test-sentiment",
        json={"text": text}
    )
    assert response.status_code == 200
    result = response.json()
    assert "sentiment" in result
    print(f"   ✅ Prédiction OK: {result['sentiment']} (score: {result['score']})")
    
    # 3. Vérifier que la prédiction est en base
    print("\n3️⃣ Vérification en base...")
    time.sleep(1)  # Attendre l'insertion
    response = requests.get(f"{BASE_URL}/historique?limit=10")
    assert response.status_code == 200
    history = response.json()
    assert len(history["data"]) > 0
    print(f"   ✅ Historique OK ({len(history['data'])} entrées)")
    
    # 4. Vérifier les statistiques
    print("\n4️⃣ Statistiques...")
    response = requests.get(f"{BASE_URL}/stats")
    assert response.status_code == 200
    stats = response.json()
    assert "total" in stats
    print(f"   ✅ Statistiques OK: {stats['total']} prédictions")
    
    # 5. Test admin (avec API Key)
    print("\n5️⃣ Admin (avec API Key)...")
    headers = {"X-API-Key": "Cle_naouel_2026"}
    response = requests.get(f"{BASE_URL}/admin/stats", headers=headers)
    assert response.status_code == 200
    admin_data = response.json()
    assert admin_data["status"] == "success"
    print("   ✅ Admin OK")
    
    print("\n" + "="*60)
    print("🎉 WORKFLOW COMPLET VALIDÉ !")
    print("="*60)