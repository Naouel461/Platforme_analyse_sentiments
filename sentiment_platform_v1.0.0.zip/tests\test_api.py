import requests
import json

BASE_URL = "http://localhost:8002"   # bien le port 8002

def test_health():
    """Vérifie que l'API est accessible (endpoint /)"""
    response = requests.get(f"{BASE_URL}/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"

def test_predict_positive():
    """Test de prédiction positive avec /test-sentiment"""
    data = {"text": "Ce produit est génial !"}
    response = requests.post(f"{BASE_URL}/test-sentiment", json=data)
    assert response.status_code == 200
    result = response.json()
    assert result["sentiment"] == "POSITIVE"   # ou "positive" selon votre API
    assert "score" in result

def test_predict_negative():
    """Test de prédiction négative"""
    data = {"text": "Service horrible"}
    response = requests.post(f"{BASE_URL}/test-sentiment", json=data)
    assert response.status_code == 200
    result = response.json()
    assert result["sentiment"] == "NEGATIVE"
    assert "score" in result

def test_predict_empty():
    """Test avec un texte vide : doit retourner NEUTRAL"""
    data = {"text": ""}
    response = requests.post(f"{BASE_URL}/test-sentiment", json=data)
    assert response.status_code == 200
    result = response.json()
    assert result["sentiment"] in ("NEUTRAL", "neutral")

def test_history():
    """Test de l'endpoint /historique"""
    response = requests.get(f"{BASE_URL}/historique?limit=5")
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert "total" in data