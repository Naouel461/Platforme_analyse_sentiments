import pytest
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

def test_db_connection():
    """Teste la connexion à PostgreSQL"""
    try:
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST", "localhost"),
            port=os.getenv("DB_PORT", 5432),
            user=os.getenv("DB_USER", "Naouel"),
            password=os.getenv("DB_PASSWORD", "Pino2026"),
            database=os.getenv("DB_NAME", "sentiment_db")
        )
        assert conn is not None
        conn.close()
        print("✅ Connexion DB OK")
    except Exception as e:
        pytest.fail(f"❌ Erreur DB: {e}")

def test_db_table_exists():
    """Teste que la table predictions existe"""
    conn = psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", 5432),
        user=os.getenv("DB_USER", "Naouel"),
        password=os.getenv("DB_PASSWORD", "Pino2026"),
        database=os.getenv("DB_NAME", "sentiment_db")
    )
    cur = conn.cursor()
    cur.execute("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_name = 'predictions'
        );
    """)
    exists = cur.fetchone()[0]
    assert exists is True
    cur.close()
    conn.close()
    print("✅ Table predictions existe")

def test_db_insert():
    """Teste l'insertion dans la base"""
    conn = psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", 5432),
        user=os.getenv("DB_USER", "Naouel"),
        password=os.getenv("DB_PASSWORD", "Pino2026"),
        database=os.getenv("DB_NAME", "sentiment_db")
    )
    cur = conn.cursor()
    
    # Insérer un test
    cur.execute(
        "INSERT INTO predictions (text, sentiment, confidence) VALUES (%s, %s, %s) RETURNING id",
        ("Test DB insertion", "POSITIVE", 0.95)
    )
    test_id = cur.fetchone()[0]
    conn.commit()
    
    # Vérifier
    cur.execute("SELECT text, sentiment FROM predictions WHERE id = %s", (test_id,))
    result = cur.fetchone()
    assert result[0] == "Test DB insertion"
    assert result[1] == "POSITIVE"
    
    # Nettoyer
    cur.execute("DELETE FROM predictions WHERE id = %s", (test_id,))
    conn.commit()
    
    cur.close()
    conn.close()
    print("✅ Insertion DB OK")